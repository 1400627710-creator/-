"""Versioned, trusted system prompts."""
