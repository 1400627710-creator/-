# 语言转换指令中继器 · 私人版 1.3.0

一个本机运行、单用户使用的中文 Web 应用。你输入模糊想法，由 OpenAI GPT 或已连接的 ChatGPT 对话模型把它整理成可交给编程 AI 的开发指令。应用本身不生成项目源码。

**Windows 完整包：** [下载 language-relay-windows-1.3.0.zip](https://github.com/1400627710-creator/-/raw/refs/heads/language-relay-1.3.0/language-relay/downloads/language-relay-windows-1.3.0.zip)。全部解压后，进入 `language-relay`，双击 **`启动中继器.bat`**。你的 Python 3.14.8 可用，无须安装 3.11。先阅读包内 `开始使用.txt`。本地页面打开不需要 API Key 或账号登录。

## 1. 变更摘要

1.3.0 新增可由 ChatGPT 或其他 MCP 宿主直接调用的工具模式，保留 API 与官方计划授权方式：

- 当前宿主对话的模型负责理解、架构、模块、接口与风险分析；中继器只校验、保存并渲染，不额外请求模型 API。工具模式不需要中继器的模型 API Key。
- 提供 9 个正式 MCP 工具，支持 Streamable HTTP 与 stdio；网页可保存待处理任务，由宿主接续，结果自动同步到原会话。
- 任务、模式和结果持久化；同一请求或结果重复提交不重复保存，新输入使旧任务失效，取消保留原输入。
- 继续执行固定七节、只问最多5题、默认假设、来源标记和 R/O/Q→M/I/T/C/K 的规划检查；拒绝任意 Markdown、循环依赖、缺失覆盖和未执行却宣称通过的测试。
- 增加“一键自检工具接口”“复制工具报错”和中文接入页；区分本机协议正常、隧道配置和实际工具调用，不把自检或保存 Tunnel ID 当作已安装到 ChatGPT。
- 新增“连接ChatGPT工具.bat”：检查本机协议、官方 client、Tunnel ID、运行凭据、init、doctor、run；每个失败阶段输出安全报错并可反馈。
- 新表 ToolTask 为增量创建，旧会话与原 Generation 记录保留。宿主结果来源单独保存，不虚构宿主模型名称、温度或 API 生成记录。
- 保留“启动中继器.bat”“一键自检.bat”和原登录地区错误修复；模型权限仍以官方结果为准。

**长期使用条件：** 插件仍安装在你的 ChatGPT 工作区、权限有效、电脑及本机服务与官方隧道在线。此安装包不能为工作区自动授予权限，也不声称已经连接了你的 ChatGPT 账户。网页版访问私有 localhost 需官方安全隧道；其运行凭据与模型 API Key 用途不同。详见 [TOOL_GUIDE.md](TOOL_GUIDE.md)。

技术实现为 Python 3.11+（已验证 3.11 和 3.14.8）、FastAPI、Uvicorn、Pydantic、SQLAlchemy、SQLite、OpenAI Python SDK、Jinja2、HTMX、Tailwind 和原生 JavaScript。

**资源加载调整：** 为同时满足“除 OpenAI API 外不向第三方上传数据”和“首屏 ≤1 秒”，没有在浏览器中使用 Tailwind CDN。交付包提供编译后的 Tailwind CSS 和完整 HTMX 文件，不需要 Node.js，也没有远程字体、统计脚本或其他运行时 CDN 请求。

## 2. 完整文件树

```text
language-relay/
  .dockerignore
  .env.example
  .gitignore
  ACCEPTANCE.md
  CHANGELOG.md
  Dockerfile
  QUALITY.md
  README.md
  TOOL_GUIDE.md
  app/
    __init__.py
    api/
      __init__.py
      routes.py
      tool_routes.py
    config.py
    db.py
    errors.py
    main.py
    mcp_tools.py
    models.py
    prompts/
      __init__.py
      relay_prompt.py
    schemas.py
    services/
      __init__.py
      chatgpt_auth.py
      connection_service.py
      diagnostics_service.py
      llm_client.py
      planning_service.py
      relay_service.py
      session_service.py
      settings_service.py
      tool_access.py
      tool_service.py
  bootstrap.py
  diagnose.bat
  diagnose.py
  mcp_stdio.py
  pytest.ini
  requirements-dev.txt
  requirements.txt
  ruff.toml
  run.py
  start.bat
  start.sh
  static/
    app.css
    app.js
    icon.svg
    vendor/
      HTMX-LICENSE.txt
      TAILWIND-LICENSE.txt
      htmx.min.js
      tailwind.css
  tailwind.config.cjs
  templates/
    index.html
    session_list.html
    tool_guide.html
  tests/
    __init__.py
    conftest.py
    fakes.py
    test_api.py
    test_bootstrap.py
    test_connection.py
    test_diagnostics.py
    test_feedback.py
    test_key_recovery.py
    test_login_recovery.py
    test_planning_service.py
    test_quality_check.py
    test_relay_service.py
    test_tool_connect.py
    test_tools.py
  tool_check.py
  tool_connect.py
  tools/
    browser_check.py
    live_check.py
    mcp_check.py
    quality_check.py
    tailwind.input.css
    tool_browser_check.py
  一键自检.bat
  启动中继器.bat
  安装说明.txt
  开始使用.txt
  诊断使用说明.txt
  连接ChatGPT工具.bat
```

运行后会出现 `.data/`，它不是交付源码的一部分。其中 `relay.sqlite3` 存储会话、消息、生成记录和模型/温度；`api-key.json` 保存通过页面设置的密钥，`chatgpt-auth.json` 保存本机 ChatGPT 注册身份和授权；`chatgpt-login-result.json` 仅保存安全的中文登录结果，不含授权码或令牌。`chatgpt-connection-result.json` 保存最近模型调用结果，并用仅在本机使用的身份指纹防止套用其他账号的旧结果；接口和诊断不导出这个指纹。`chatgpt-login-trace.json` 仅保存经过字段筛选的授权阶段记录；`diagnostics-latest.json` 保存最近的安全自检报告。`operation-results.json` 只保存允许列出的环节、错误码、时间和 HTTP 证据，不包含用户输入或原始日志；同一步成功重试会替换对应失败状态。独立诊断工具将报告写入 `diagnostics/`。也可以通过 `.env` 或环境变量配置密钥。

安装记录写入 `.data/install.log`。`.data/startup.lock` 和 `.data/server.lock` 用于防止重复安装或运行，进程退出后操作系统自动释放锁。`.data/active-server.json` 记录本机端口、版本和随机实例编号，重复启动时只有验证匹配才重新打开页面；不包含模型凭据。无法使用的旧虚拟环境保留为 `.venv-backup-…`。

## 3. 每个文件的完整代码

交付 ZIP 内包含上面全部文件，无省略号、伪代码或待补实现。[下载 language-relay-full-source-1.3.0.md](https://github.com/1400627710-creator/-/raw/refs/heads/language-relay-1.3.0/language-relay/downloads/language-relay-full-source-1.3.0.md)，按文件逐一列出完整内容，包括第三方静态文件和许可文本。`downloads/` 是仓库的下载附件目录，不放入 ZIP 中，避免递归打包。

### 数据与输出契约

- `Session`：标题、状态、默认假设模式、错误信息、创建和更新时间。
- `Message`：会话、角色、类型（输入/问题/完整报告）、内容、创建时间。
- `ToolTask`：持久化宿主任务、幂等请求编号、上下文版本、重试预算和已保存输出的消息编号；不存宿主模型或温度。
- `Generation`：来源输入、对应输出消息、完整 Markdown、模型、温度、默认假设模式和创建时间。
- `Setting`：连接方式、API 模型、ChatGPT 模型、API 温度；API Key 和 OAuth 令牌不写入这个表。ChatGPT 连接不使用温度参数。

GPT 返回经过 JSON Schema 约束的结构化内容。Pydantic 和业务校验进一步检查问题数量、章节内容、必需子项、数字与单位、换行和模式约束。服务端将其拼成固定标题的 Markdown：

1. 我理解的想法
2. 动机分析
3. 需要确认的问题
4. 需求规格
5. 技术方案
6. 给编程 AI 的指令
7. 自检

第 6 节独立包含角色、目标、上下文、技术栈、功能清单、文件结构、接口定义、验收标准、输出格式、分步任务。必须做与可选做分别列出。

1.2.0 的结构化规划使用同一份需求清单生成第 4 / 6 节，用 R/O/Q 编号连接模块 M、接口 I、任务 T、验收 C 和风险 K。模块与任务必须无循环，每个必须需求和量化指标都有模块、任务和验收；接口必须归属负责该需求的模块。文件只能归属一个模块，不能用大小写、父目录或文件/目录冲突重复分配。任务按前置依赖排序，可选工作单独列出。

每个接口定义输入、返回、错误、权限、重复调用与两个例子，架构包含选择/备选/理由/代价，风险包含触发/处理/验证。第 7 节显示程序实际执行的结构检查和映射表，并明确尚未实现目标项目、没有执行其测试。来源标记约束仍逐项应用于新的所有说明。

具体数据字段、适用边界和五项能力验收见 [QUALITY.md](QUALITY.md)。升级增量创建 ToolTask 表，不修改旧表或旧 Markdown；旧历史仍能原样查看、复制和导出。

标记“用户已提供”需要模型返回的内容与依据相同，且依据是用户输入中的完整语句；校验保留词与数字之间的空格，并检查语句边界。例如，“不需要联网”不能截成“需要联网”，“首屏 ≤1 0 秒”不能合并为“首屏 ≤10 秒”。无法核验的片段、改写和新增内容均标记“假设”。这项检查约束来源标记，复杂内容的语义正确性仍需真实 API 验收和人工检查。

信息不足时只有 `## 3. 需要确认的问题`，不添加其他章节。默认假设模式下，第 3 节说明没有阻塞问题，全部补充内容依然逐项标记“假设”。默认假设模式会沿用到本会话的后续修改；输入“不使用默认假设”“不要使用默认假设”“取消默认假设”或“我不需要结果”可以退出。一次输入包含多个明确模式要求时，以最后一个为准。引号、代码块、行内代码、JSON 字符串或 Markdown 引用中的触发词视为项目资料，不改变模式。

输入框下会说明草稿是否已保存。未发送内容仅保存在当前浏览器的本机存储中，不会调用 GPT；发送后消息与生成历史存入 SQLite。清除浏览器数据会清除草稿，已经发送的历史继续保存在数据库。浏览器存储不可用时会提示草稿仅在当前页面暂存。草稿按会话编号和创建时间区分，避免数据库重新使用编号时套用旧草稿。

### HTTP 接口

写入请求需要额外请求头 `X-Relay-Client: local`，这是本地网页防护的一部分。浏览器已自动添加，命令行调用时请自行添加。不启用跨域访问。

| 方法 | 路径 | 请求 / 响应 |
| --- | --- | --- |
| GET | `/health` | `{"status":"ok"}` |
| GET | `/api/runtime` | 本机程序名称、版本、实例编号、端口；仅用于验证本项目启动页面，不返回模型凭据 |
| GET | `/api/settings` | 是否有密钥、API 模型、温度、`provider`、`chatgpt_model`，不返回秘密 |
| PUT | `/api/settings` | 可选 `openai_api_key`、`model`、`temperature`、`provider`（`api` / `chatgpt`）、`chatgpt_model` |
| POST | `/api/settings/import-key` | `{"content":"密钥或配置文件内容"}`；返回设置与连接检测结果，不回显密钥 |
| POST | `/api/settings/test-connection` | 无正文；检测已选连接，默认最多 10 秒 |
| POST | `/api/auth/chatgpt/start` | 无正文；返回官方授权网址，浏览器打开后完成登录。显式补授权使用 `?authorize_plan=true`，请求 `prompt=consent` |
| GET | `/auth/callback` | 官方 OAuth 回调；验证后 303 跳转，清除网址中的授权码 |
| GET | `/api/auth/chatgpt/status` | 账号登录、模型授权、等待回调、阶段、账户、模型与结果，不返回令牌 |
| POST | `/api/auth/chatgpt/cancel` | 无正文；取消当前等待，不删除已有有效授权 |
| POST | `/api/auth/chatgpt/models` | 无正文；刷新账户可用模型 |
| POST | `/api/auth/chatgpt/logout` | 无正文；清除本机令牌并尝试官方撤销 |
| POST | `/api/diagnostics/run` | `{"check_network":true}`；生成安全 JSON 报告，网络检查共享 6 秒上限，不调用模型 |
| GET | `/api/diagnostics/export` | 导出最近的安全 JSON 报告；无报告时 404 |
| POST | `/api/sessions` | 可选 `title`，返回会话（201） |
| GET | `/api/sessions` | 按更新时间排序的会话数组 |
| GET | `/api/sessions/{id}` | 会话信息与消息数组 |
| PATCH | `/api/sessions/{id}` | `{"title":"名称"}`，重命名 |
| POST | `/api/sessions/{id}/messages` | `{"content":"想法"}`；返回输出消息、原输入、问题和 Markdown |
| POST | `/api/sessions/{id}/generate` | `{"use_default_assumptions":true}`；返回生成编号和 Markdown |
| POST | `/api/sessions/{id}/retry` | 无正文；重试失败请求，不重复保存输入 |
| GET | `/api/sessions/{id}/export` | 当前最新输出的 UTF-8 `.md` |
| GET | `/api/sessions/{id}/export?message_id=…` | 导出指定输出消息，不能读取其他会话的消息 |
| DELETE | `/api/sessions/{id}` | `{"ok":true}`，关联消息与生成记录级联删除 |

`generate` 必须已有项目想法。设置 `use_default_assumptions:false` 会明确退出默认假设模式；若仍缺信息，问题被保存，接口返回 409。

错误统一为 `{"detail":{"code":"…","message":"中文提示",…}}`。输入校验错误只给字段名称和说明，不回传密钥或原请求正文。API Key 缺失、无效、API 余额不足、ChatGPT 计划额度耗尽和模型配置不支持属于需要处理的错误，需要先修改设置，不做无效的网络重试。OpenAI 明确要求等待的 `Retry-After` 超出总预算时，应用给出限流提示，不提前重试，也不无限等待。

超时、连接失败、限流、服务端暂时失败和输出格式错误按预算自动重试，最多首次加两次。客户端内部异常或输出处理异常保存中文错误并允许手动重试；任务取消也会保存中断状态，刷新后可重试原输入。错误正文与异常日志不包含上游响应或密钥。

### 提示词与数据边界

系统提示词只来自 `app/prompts/relay_prompt.py`。用户输入及历史结果作为不可信 JSON 资料放在 `user` 消息内，不能向设置接口写入系统提示词。章节和标记由程序生成，模型返回不合格内容时不会展示为合格结果。

这保证消息角色和固定格式由应用控制；它不代表模型对所有复杂恶意文字都能做出正确语义判断。真实内容是否贴合想法、技术是否合适，需要用真实 API 验收和人工检查确认。

## 4. 安装与运行命令

### Windows：最少操作

1. 已安装 64 位 Python 3.11 或更新版本（包括 3.14.8）时，直接进行下一步。若尚未安装，访问 [Python 官方下载页面](https://www.python.org/downloads/)，安装完整的 64 位 Python；使用传统安装程序时勾选 `Add python.exe to PATH`，再点击 `Install Now`。
2. 右键 ZIP，选择“全部解压”，解压到桌面或文档中的普通文件夹。进入其中的 `language-relay` 文件夹。
3. 双击 **`启动中继器.bat`**（`start.bat` 是兼容入口）。首次运行会安装依赖，保持联网，等待“依赖与程序环境校验通过”。
4. 网页会在服务就绪后自动打开。也可以按启动窗口显示的网址进入，通常是 [http://127.0.0.1:8000](http://127.0.0.1:8000)；端口占用时窗口显示备用网址。启动窗口需要保持打开。
5. 若要通过当前 ChatGPT 对话使用，点击“连接 ChatGPT 工具”，保存工具模式，执行本机协议自检，按 [TOOL_GUIDE.md](TOOL_GUIDE.md) 一次配置官方安全隧道及插件，以后运行“连接ChatGPT工具.bat”即可续接。也可保留 API 或“使用 ChatGPT 登录”的直接模型方式，它们需要各自的官方权限；不是工具模式的必经登录步骤。
6. 输入“我想做卡牌游戏”，发送；补充回答，或点击“使用默认假设，我需要结果”。
7. 使用“复制 Markdown”“复制第 6 节”或“导出 .md”获得结果。

已有 1.0.0–1.2.0 版本时，关闭原启动窗口，解压新版并替换原项目的代码文件，保留原项目的 `.data` 和 `.env`，再双击新版 `启动中继器.bat`。新版会核验当前虚拟环境并按需修复；同一电脑升级保留 `.data` 和 `.env`。更换电脑可迁移历史与 API 配置，但不要复制 `.data/chatgpt-auth.json`；在新电脑重新登录 ChatGPT，由程序建立不同的本机注册身份。不要复制 `.venv`。本次没有改变数据库表结构，已有会话和密钥配置可以继续使用。重新生成历史会话的结果，可应用新的原话核验规则。

不需要激活虚拟环境。手动运行命令（PowerShell，在项目文件夹内）：

```powershell
py bootstrap.py
```

已有 Python 3.14.8 时可直接使用，无须另外安装 3.11。需要指定现有 3.14 时执行 `py -V:3.14 bootstrap.py`。若电脑没有 `py` 命令但有 Python 3.11+，改用 `python bootstrap.py`。双击入口优先使用 `py -3`，再尝试 `py -3.11`、`python` 和可用的现有虚拟环境。

### macOS / Linux

```bash
sh start.sh
```

启动入口优先选择 Python 3.11，再尝试 Python 3.11+。可用 `RELAY_PYTHON=python3.11 sh start.sh` 指定解释器；在无图形界面的环境使用 `sh start.sh --no-browser`。仅检查与安装依赖可执行 `python3.11 bootstrap.py --install-only`。

### 安装失败时

启动窗口保留具体错误，安装记录位于项目的 `.data/install.log`。网络恢复后重新双击启动文件即可重试，历史记录和密钥配置保留。

| 提示或现象 | 操作 |
| --- | --- |
| 提示需要 Python | 安装上面链接的完整 64 位 Python 3.11 或更新版本，勾选加入系统路径；关闭旧窗口再启动 |
| `No runtime installed that matches 3.11` | 命令指定了未安装的版本；运行 `py bootstrap.py`，已安装 3.14 时可用 `py -V:3.14 bootstrap.py` |
| 依赖下载失败 | 检查网络，重新启动；若持续失败，提供窗口末尾的报错或安装记录末尾内容 |
| 程序文件无法写入 | 完整解压到桌面或文档中的普通文件夹，再启动 |
| 旧程序环境无法使用 | 按提示等待自动重建，旧环境备份保留在项目文件夹内 |
| 已有本项目启动窗口 | 再次双击会验证并重新打开原页面；提示旧版本时先关闭旧窗口，再启动新版 |
| 浏览器没有自动打开 | 将启动窗口里的完整网址粘贴到浏览器地址栏 |
| 提示本地配置无法使用 | 检查 `.env` 的温度为 0–2、预算为 1–28 秒，数据目录可写 |

Python 3.14.8 与 Python 3.11 的完整测试与浏览器结果见 ACCEPTANCE.md。1.3.0 的实际 MCP、浏览器、跨 Python 版本、安装文件兼容性检查见 ACCEPTANCE.md；没有在用户的 Windows 真机执行双击启动，也没有取得用户的官方隧道凭据。

此程序需要完整 Python 安装中的 `venv` 与 `ensurepip`。Linux 发行版若拆分这两个组件，需安装对应的 `python3-venv` 包。

### 先自检并反馈连接问题

**官方地区拒绝：** 如果报告在 `token_exchange` 等环节记录 HTTP 403 和 `unsupported_country_region_territory`，说明官方拒绝本次请求的国家、地区或领土。应用没有取得令牌，显示未授权是正确状态。打开新中继器标签页只说明回调返回。版本 1.3.0 会明确显示阶段与具体错误码，不再归为原因未知；较早的 API Key 错误不会盖过当前 ChatGPT 登录失败。

核对 [OpenAI 官方支持地区](https://developers.openai.com/api/docs/supported-countries) 和 [官方错误说明](https://developers.openai.com/api/docs/guides/error-codes)。如果在受支持地区仍被拒绝，可通过 OpenAI 官方帮助中心联系支持，提供发生时间、失败阶段和官方错误码。报告不能确定官方判定的地区或依据；软件更新、刷新模型和导入 API Key 不能授予被拒绝的权限。

报告若显示 Windows 浏览器代理开启、后端直接连接，只能确认网络配置不同。假设：请求出口可能不同；本报告未探测出口 IP 或地区，不能把该差异确定为 403 原因。诊断不会更改网络配置。

你遇到的两条旧提示有不同来源：第一条来自统一的 HTTP 403 错误映射，不能证明具体是账户、地区还是工作区限制；第二条来自本机没有可用计划授权的检查，通常是前一次失败的后续结果。刷新模型不是重新授权。浏览器账号登录、允许本应用使用计划、回调交换验证以及本机保存分别检查。

新版页面：关闭旧启动窗口、保留 `.data` / 自己的 `.env`、覆盖新版代码后双击 `启动中继器.bat`。重新完成一次登录；已登录但未授权时点击“授权模型调用”，出错后在“连接与设置”点击“一键自检并导出”，把下载的 `relay-diagnostics-*.json` 反馈即可。取消网络选项可完全离线自检。界面读取已保存的设置，不会发送未保存的密码框内容。

旧版或页面打不开：将独立诊断包里的 `diagnose.py`、`diagnose.bat` 放到现有项目，与 `start.bat` 同级，保持启动窗口打开，再双击 `diagnose.bat`。新版可直接双击 `一键自检.bat`。发送旁边 `diagnostics/` 文件夹中的最新 JSON。工具只需 Python 3.11+；你已有的 3.14.8 可以使用，无需安装 FastAPI。多进程时必须指定对应窗口的端口；检测到多个服务时不会猜测。

```powershell
py -V:3.14 diagnose.py
py -V:3.14 diagnose.py --offline
py -V:3.14 diagnose.py --port 8001
```

记录包括运行进程 Python/依赖版本、可写目录、授权文件的存在与可读标志、回调/交换/签名/权限/保存/模型调用阶段、最近模型调用结果、第一次授权失败、安全 HTTP 元数据，以及可选的官方 DNS/TLS/超时和响应时钟差。未知错误码、不合安全格式的请求 ID 会隐藏。报告不导出账号标识、凭据、原始日志或上游正文；不会自动上传。网络设置差异只作为“假设”，不能据此断定你的地区或账户政策。

旧版丢弃的具体阶段和上游错误无法从中文提示还原；这种报告标记“旧版详情缺失”，升级后再登录一次即可记录。公开接口可达不代表计划授权成功，模型列表可达也不等于实际生成成功。详见 `诊断使用说明.txt`。

### 两种模型连接与错误自查

**免 API Key：** 选择“使用 ChatGPT 登录”，点击“使用 ChatGPT 继续”。官方页面负责登录与授权，本应用不接收你的账号密码。完成本应用授权并返回后读取账户可用模型列表；若列表暂时加载失败，可以点击“刷新可用模型”。这是需要官方授权的调用方式，不能在未登录、未授权或账户不符合条件时匿名调用模型。你在这个对话中使用的模型是否出现在账户列表，以官方返回结果为准。

**官方页面登录后应用没有同步：** 返回“连接与设置”，点击“检查登录状态”。页面会区分以下情况；不用反复刷新或重新导入 Key。

| 登录状态 | 操作 |
| --- | --- |
| 等待官方授权返回 | 回到刚打开的官方页面，完成账号登录和本应用计划授权，允许跳回本机中继器；只登录 ChatGPT 首页不能完成本次应用授权 |
| 已收到回调，正在完成授权 | 保持启动窗口打开，等待本机完成授权交换和身份验证 |
| 账号已登录，但模型尚未授权 | 账号身份已确认，仍缺少计划调用许可；点击“授权模型调用”并按官方页面重新允许计划使用；普通登录和刷新模型不会代替补授权 |
| 无法连接官方授权服务 | 官方网页与本机 Python 的网络连接分别验证；检查本机是否能访问官方接口，页面显示具体失败原因 |
| 官方明确返回国家或地区不受支持 | 回调页显示 `chatgpt_region_unsupported` 与官方代码；核对官方支持地区，在受支持地区仍失败时联系官方支持。刷新、重装或 Key 不能改变此拒绝 |
| 身份验证未通过 | 检查电脑日期与时间，重新发起登录；应用不会跳过签名或身份校验 |
| 登录被服务重启中断、等待已过期 | 从本应用重新开始登录，完成新授权；旧回调不能用来代替新请求 |
| 模型列表尚未加载 | 登录结果保留，点击“刷新可用模型”；无需把账号登录重新当成失败 |
| 模型授权已完成，但连接检测失败 | 身份与计划状态保留；按模型连接第三步的具体原因处理，再点击“保存并检测连接”。自检记录模型调用阶段，不把一般 403 误判为资格限制 |

“重新打开官方授权页”会沿用当前请求；确实要重新开始时先点击“取消本次登录”。取消新请求不会删除原有的有效授权。

**API Key：** 粘贴完整密钥并点击“导入并检测”；或者选择包含密钥的 `.txt`、`.env`、JSON 文件，选择后自动导入和检测。支持 `.env` 的 `OPENAI_API_KEY=...` 以及 JSON 的 `openai_api_key` / `OPENAI_API_KEY` 字段；文件最多 16 KiB，密钥最多 512 字符。检测只发送简短合成测试，会计入对应 API 或计划用量。修改模型后点击“保存并检测连接”再次验证。

| 检测提示 | 下一步 |
| --- | --- |
| API Key 无效 | 从 API 平台复制完整密钥重新导入 |
| API 额度不足或计费未启用 | 检查 API 平台余额和项目计费；它与 ChatGPT 订阅分别管理 |
| 模型或权限不支持 | 选择账户有权使用且支持结构化输出的模型 |
| 无法连接官方接口、超时 | 检查网络；换密钥不会修复网络连接 |
| ChatGPT 登录失效 | 重新点击“使用 ChatGPT 继续” |
| HTTP 403 或计划权限拒绝 | 一键自检，核对失败阶段与安全错误码；明确资格拒绝才按官方限制处理 |
| ChatGPT 计划或本应用额度用尽 | 点击输入区旁“管理额度”，查看 ChatGPT 设置中的用量 |

应用网页本身不需要 Key 才能打开；若网页根本无法访问，应先查看启动窗口显示的网址和启动错误。

官方协议依据：[注册和登录](https://developers.openai.com/siwc/token-sharing-open-source/sign-in)、[模型与调用](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference)、[预览限制](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations)、[错误恢复](https://developers.openai.com/siwc/token-sharing-open-source/errors-and-recovery)。这些能力可能随官方预览调整，本应用不会绕过资格或额度限制。

### 本地配置

也可以复制 `.env.example` 为 `.env`，填写 `OPENAI_API_KEY`、`OPENAI_MODEL`、`OPENAI_TEMPERATURE`。页面保存的配置优先于启动配置；页面清除密钥后，不会重新采用 `.env` 中的旧密钥。

- 温度范围 0–2，默认 0.2。
- API Key 格式要求为不含空格的可打印 ASCII 字符，最多 512 个字符；保存配置不代表密钥已通过 OpenAI 验证。身份验证失败时，页面提示修改设置后重试。
- 模型需要支持结构化输出的 Chat Completions API。未支持该参数的模型会得到配置提示，不悄悄替换模型。
- `RELAY_DATA_DIR` 默认 `.data`，相对路径以项目目录为基准。
- `RELAY_LLM_BUDGET_SECONDS` 可配置 1–28 秒；默认 28 秒是包括 ChatGPT 授权刷新、生成调用与重试等待的总预算。
- 程序只监听 `127.0.0.1`，每个项目使用一个进程；默认端口 8000，冲突时选用 8001–8010。不提供局域网多人访问。
- OpenAI 客户端不继承进程环境的代理设置，不跟随 HTTP 重定向；本地真实验收脚本也直连本机。请使用能够直接访问 OpenAI 官方接口的网络。
- 密钥和 ChatGPT 授权文件是本地明文配置，POSIX 系统权限为 600、目录为 700；Windows 沿用当前用户的文件权限。不要分享包含密钥或授权的 `.env`、`.data`。正式启动入口关闭访问日志；自行使用 Uvicorn 时请添加 `--no-access-log`，避免记录 OAuth 回调授权码。

### 可选 Docker

```bash
docker build -t language-relay .
docker run --rm --name language-relay -p 127.0.0.1:8000:8000 -v relay-data:/relay/.data language-relay
```

浏览器仍打开 `http://127.0.0.1:8000`，通过页面配置密钥。数据保存在 Docker 命名卷。构建上下文排除 `.env` 和 `.data`，容器内使用普通用户运行。

### 可选更新 Tailwind 样式

正常安装、运行和使用均不需要 Node.js。开发者修改工具类后，可以安装 Node.js 并在项目目录执行：

```bash
npx --yes --package=tailwindcss@3.4.19 tailwindcss -i tools/tailwind.input.css -o static/vendor/tailwind.css --minify
```

HTMX 2.0.11 和 Tailwind 3.4.19 的许可随静态文件提供。应用 API 的结构化输出设计参考 [OpenAI 官方文档](https://developers.openai.com/api/docs/guides/structured-outputs) 和 [gpt-4o-mini 模型说明](https://developers.openai.com/api/docs/models/gpt-4o-mini)。

## 5. 测试命令

新增工具检查（不调用模型，不访问已有用户会话）：

```powershell
.\.venv\Scripts\python.exe tools\mcp_check.py
.\.venv\Scripts\python.exe tools\tool_browser_check.py
```

网页点击“一键自检工具接口”只初始化协议与发现工具；不会把内部检查计为宿主调用。界面显示“已收到工具调用”仍不独立证明客户端身份。


### 自动化测试：不需要密钥，不会调用 OpenAI

Windows：

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

macOS / Linux：

```bash
.venv/bin/python -m pytest -q
```

### 可选浏览器检查：使用临时数据库和模拟 GPT

以下以通用 `python` 命令展示，请替换为上面的虚拟环境 Python 路径：

```bash
python -m pip install -r requirements-dev.txt
python -m playwright install chromium
python tools/browser_check.py
python -m ruff check app tests tools bootstrap.py run.py diagnose.py
```

检查会自行启动临时本地服务，完成界面操作、复制、下载、密钥纠正与重试、内部异常恢复、草稿隔离与恢复、生成中刷新、响应丢失恢复、模式取消、补充回答、重命名、删除、深色模式、移动布局、密钥文件导入、官方 OAuth 回调、账户模型列表、断开授权、等待期间刷新、重复打开授权页、状态请求故障恢复、未授权身份登录、失败原因恢复与取消登录检查，以及自检下载、复制、首次失败原因、专用补授权按钮、模型 403 分类、刷新保留与连接成功恢复检查。OAuth 服务与模型响应均模拟，实际验证签名和 SDK 请求协议。不会修改你的正式数据库，也不会调用 OpenAI。截图和 JSON 记录默认写入 `test-results/browser/`，可使用 `--output` 指定其他目录。

### 独立真实 API 验收

先运行正式应用，在页面配置真实 API Key 或完成 ChatGPT 官方授权，再另开一个命令窗口执行：

```bash
python tools/live_check.py
```

这条命令确实调用 OpenAI：只发送两条合成验收输入“我想做卡牌游戏”和“使用默认假设，我需要结果”。它检查问题、7 节格式、第 6 节内容、导出一致性与每次请求耗时，并删除创建的临时会话。失败会显示中文提示。它不由普通 pytest 自动执行。

若启动窗口显示备用端口，例如 8001，使用 `python tools/live_check.py --url http://127.0.0.1:8001`。验收脚本仅接受本机 HTTP 网址。

### 五项能力的真实模型验收

见 `QUALITY.md`。先离线查看案例，再明确调用模型：

```bash
python tools/quality_check.py --list-cases
python tools/quality_check.py --live --url http://127.0.0.1:8000
```

第二条命令会消耗所选 API / ChatGPT 计划额度，只使用合成输入和临时会话。Markdown 与评审 JSON 写入本机 `quality-reports/`，不会自动上传。契约检查通过不等于内容质量已确认，五项内容维度仍需人工评审。

## 6. 验收自查表

完整结果与限制见 `ACCEPTANCE.md`。

| 验收要求 | 实现与验证 |
| --- | --- |
| 卡牌游戏想法不足时仅输出第 3 节，问题 ≤5 | 已实现，自动化与浏览器模拟测试通过；真实判断待真实 API 验证 |
| 要求默认假设后直接输出 1–7 节 | 已实现，自动化与浏览器模拟测试通过 |
| 所有假设标记“假设” | 服务端逐项标记；未通过完整语句与依据核验的“用户事实”也降级为假设 |
| 第 6 节包含十项内容 | 结构模型强制存在，渲染与浏览器复制检查通过 |
| 一键复制格式不乱 | 实际 Chromium 剪贴板内容与页面原文完全一致 |
| MCP 工具模式 | 协议/目录、完整流程、保存、重试、网页同步、复制导出和重启持久化通过；用户工作区及官方隧道连接待配置 |
| API Key 与免 Key 连接 | 一步导入和检测、错误分类、官方登录协议、令牌刷新和撤销已覆盖；真实账户资格待实测 |
| 一键诊断与反馈 | 分阶段 403 分类、首次原因保留、报告脱敏、旧版缺失提示、离线运行与回调并发通过 |
| 需求、架构、模块、接口、风险和自检 | 统一需求映射、完整接口、依赖/文件/任务/验收检查、具体修复反馈与旧历史兼容已覆盖；真实内容质量待模型与人工验收 |
| GPT 暂时失败重试 2 次 | 超时、格式、连接失败的三次尝试与总预算已验证 |
| 刷新后历史仍在 | 浏览器刷新与数据库关闭重启测试通过 |
| 导出与页面一致 | 对当前结果和选中的历史版本进行逐字节比较，通过 |
| 首屏 ≤1 秒，GPT 响应 ≤30 秒 | 浏览器实际首屏通过；授权刷新与生成的共同预算默认 28 秒。真实 GPT 成功响应的速度尚未测得，超时返回提示 |

**当前限制：** 本次 Python 3.11 / 3.14.8 各 400 项测试、53 项原有浏览器流程、11 项工具浏览器流程和8项真实 MCP 协议检查通过；OAuth 上游和模型响应使用模拟服务。Python 3.14.8 的真实标准安装、进程启动、重启历史恢复通过，Windows 64 位依赖下载核验通过；用户提供的 Windows 3.14.8 报告已确认 1.2.1 的依赖、本机服务和可写目录通过，1.3.0 的 Windows 双击仍未由本环境实测。已由当前助手生成结构化方案并通过本机 MCP 校验保存；没有使用你的真实密钥、ChatGPT 账户或官方隧道验证账号接入，也没有保证所有需求场景的语义质量或宿主速度；Docker 镜像未在本环境构建。语音输入和局域网密码未实现，它们属于可选范围。
